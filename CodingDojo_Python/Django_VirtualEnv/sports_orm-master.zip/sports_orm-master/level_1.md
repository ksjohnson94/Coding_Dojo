# Simple finds

1. Find all baseball leagues
2. Find all womens' leagues
3. Find all leagues where sport is any type of hockey
4. Find all leagues where sport is something OTHER THAN football
5. Find all leagues that call themselves "conferences"
6. Find all leagues in the Atlantic region
7. Find all teams based in Dallas
8. Find all teams named the Raptors
9. Find all teams whose location includes "City"
10. Find all teams whose names begin with "T"
11. Return all teams, ordered alphabetically by location
12. Return all teams, ordered by team name in reverse alphabetical order
13. Find every player with last name "Cooper"
14. Find every player with first name "Joshua"
15. Find every player with last name "Cooper" EXCEPT FOR Joshua
16. Find all players with first name "Alexander" OR first name "Wyatt"