class SayController < ApplicationController
  def index
    render text: 'Saying hello'
  end
end
